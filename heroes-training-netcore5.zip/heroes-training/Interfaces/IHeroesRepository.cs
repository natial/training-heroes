﻿using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Iterfaces
{
    public interface IHeroesRepository
    {
        Task<IEnumerable<Hero>> GetHeroesAsync();
        Task<Hero> GetHeroByIdAsync(int id);

        Task<Hero> GetHeroByNameAsync(string name);
    }
}
