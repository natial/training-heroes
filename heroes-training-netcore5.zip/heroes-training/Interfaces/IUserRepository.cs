﻿using API.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace API.Iterfaces
{
    public interface IUserRepository
    {
        Task<IEnumerable<AppUser>> GetUsersAsync();
        Task<AppUser> GetUserByIdAsync(int id);

    }
}
