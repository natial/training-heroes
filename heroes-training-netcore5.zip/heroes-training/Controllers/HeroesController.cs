﻿using API.Controllers;
using API.Entities;
using API.Iterfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{

    public class HeroesController : BaseApiConroller
    {
        private readonly IHeroesRepository _heroesRepository;

        public HeroesController(IHeroesRepository heroesRepository)
        {
            _heroesRepository = heroesRepository;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Hero>>> GetHeroes()
        {
            return Ok(await _heroesRepository.GetHeroesAsync());
        }

        [HttpGet("{heroname}")]
        public async Task<ActionResult<Hero>> GetHero(string heroname)
        {
            return await _heroesRepository.GetHeroByNameAsync(heroname);
        }
    }
}
