﻿using API.Iterfaces;
using API.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace API.Data
{
    public class HeroRepository : IHeroesRepository
    {
        private readonly DataContext _context;

        public HeroRepository(DataContext context)
        {
            _context = context;
        }

        public async Task<Hero> GetHeroByIdAsync(int id)
        {
            return await _context.Heroes.FindAsync(id);
        }

        public async Task<Hero> GetHeroByNameAsync(string name)
        {
            return await _context.Heroes.SingleOrDefaultAsync(x => x.Name == name);
        }

        public async Task<IEnumerable<Hero>> GetHeroesAsync()
        {
            return await _context.Heroes.ToListAsync();
        }
    }
}
