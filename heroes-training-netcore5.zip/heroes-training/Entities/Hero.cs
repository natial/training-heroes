﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace API.Entities
{
    [Table("Heroes")]
    public class Hero
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Guid GuidId { get; set; }

        public DateTime StartTrainingDate { get; set; }

        public string Color { get; set; }

        public decimal StartingPower { get; set; }

        public decimal CurrentPower { get; set; }

        public int NumberOfTraining { get; set; }

        public int AppUserId { get; set; }
    }
}
