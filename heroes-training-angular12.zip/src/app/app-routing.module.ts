import { RegisterComponent } from './register/register.component';
import { NotFoundComponent } from './errors/not-found/not-found.component';
import { AuthGuard } from './guards/auth.guard';
import { ListsComponent } from './lists/lists.component';
import { HeroesListComponent } from './heroes/heroes-list/heroes-list.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeroesDetailComponent } from './heroes/heroes-detail/heroes-detail.component';

const routes: Routes = [
  {path:'', component: HomeComponent},
  {
    path:'',
    runGuardsAndResolvers:'always',
    canActivate:[AuthGuard],
    children:[
      {path:'heroes', component: HeroesListComponent},
      {path:'heroes/:heroname', component: HeroesDetailComponent},
      {path:'lists', component: ListsComponent},
    ]
  },
  {path: 'register', component:RegisterComponent},
  {path: 'not-found', component:NotFoundComponent},
  {path:'**', component: HomeComponent, pathMatch:'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
