import { map } from 'rxjs/operators';
import { User } from './../../models/user';
import { AccountService } from './../../services/account.service';
import { HeroesService } from 'src/app/services/heroes.service';
import { Component, OnInit } from '@angular/core';
import { Hero } from 'src/app/models/hero';

@Component({
  selector: 'app-heroes-list',
  templateUrl: './heroes-list.component.html',
  styleUrls: ['./heroes-list.component.css']
})
export class HeroesListComponent implements OnInit {

  heroes:Hero[];
  canTrainHero:boolean;
  user:User;
  constructor(private heroesService:HeroesService, private accountService:AccountService) { }

  ngOnInit(): void {
    this.accountService.currentUser$.subscribe((user=>{
      this.user = user;
    }))
    this.loadHeroes();
  }

  loadHeroes(){
    this.heroesService.getHeroes().subscribe(heroes=>{
      this.heroes = heroes;
    })
  }
}
