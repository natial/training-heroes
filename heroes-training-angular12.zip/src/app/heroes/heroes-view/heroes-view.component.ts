import { Component, Input, OnInit } from '@angular/core';
import { Hero } from 'src/app/models/hero';

@Component({
  selector: 'app-heroes-view',
  templateUrl: './heroes-view.component.html',
  styleUrls: ['./heroes-view.component.css']
})
export class HeroesViewComponent implements OnInit {

  @Input() hero:Hero;
  constructor() { }

  ngOnInit(): void {
  }

}
