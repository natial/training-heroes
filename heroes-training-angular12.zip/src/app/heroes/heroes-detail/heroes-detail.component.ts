import { HeroesService } from './../../services/heroes.service';
import { Component, Input, OnInit } from '@angular/core';
import { Hero } from 'src/app/models/hero';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-heroes-detail',
  templateUrl: './heroes-detail.component.html',
  styleUrls: ['./heroes-detail.component.css']
})
export class HeroesDetailComponent implements OnInit {
  @Input() hero:Hero;
  doneTraining:boolean;

  constructor(private heroesSerice: HeroesService, private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.loadHero();
  }

  loadHero(){
    this.heroesSerice.getHero(this.route.snapshot.paramMap.get('heroname')).subscribe(hero=>{
      this.hero = hero;
    })
  }

  startTraining(){
    if(this.hero.numberOfTraining == 0){
      this.hero.startTrainingDate = new Date();
    }
    this.hero.numberOfTraining++
    if(this.hero.numberOfTraining < 5){
      this.hero.currentPower += Math.floor(Math.random() * 11);
      
    }
    else{
      this.doneTraining = true;
    }
    
  }
}
