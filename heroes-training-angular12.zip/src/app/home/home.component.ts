import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  registerMode:boolean = false;
  heroes:any;

  constructor(private http:HttpClient, private router: Router) { }

  ngOnInit(): void {
  }

  registerToggle(){
    this.registerMode = !this.registerMode;
    this.router.navigateByUrl("/register");
  }

  cancelRegisterMode(event:boolean){
    this.registerMode = event;
  }
}
