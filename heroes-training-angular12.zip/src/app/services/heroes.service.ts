import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Hero } from '../models/hero';

const httpOptions={
  headers: new HttpHeaders({
    Authorization:'Bearer ' + JSON.parse(localStorage.getItem('user'))?.token
  })
}

@Injectable({
  providedIn: 'root'
})
export class HeroesService {

  
  constructor(private http:HttpClient) {
    
  }

  getHeroes(){
    return this.http.get<Hero[]>('https://localhost:5001/api/heroes', httpOptions);
  }

  getHero(heroname:string){
    return this.http.get<Hero>('https://localhost:5001/api/heroes/' + heroname, httpOptions);
  }
}
