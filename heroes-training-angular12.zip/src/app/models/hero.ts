export interface Hero{
    id:number;
    name:string;
    guidId:string;
    startTrainingDate:Date;
    color:string;
    startingPower:number;
    currentPower:number;
    numberOfTraining:number;
    appUserId:number;
}