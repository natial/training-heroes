export interface User{
    username:string;
    token:string;
    id:number;
}